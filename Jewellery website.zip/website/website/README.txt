Minimal Jewelry E-Commerce Prototype
A static HTML/CSS storefront prototype featuring collections of luxury bracelets, earrings, gold chains, and pearl necklaces. The project includes basic operational pages like an account portal, contact details, and product profiles.

📂 Project Structure
Plaintext
website/
├── about us.html        # Company overview
├── about us.txt         # Text source for the About section
├── account.html         # User account login/registration page
├── account.txt          # Text templates for account operations
├── contact us.html      # Customer service page with embedded forms
├── contact us.txt       # Text source for company contact info
├── home page.html       # Storefront homepage
├── homepage.txt         # Homepage copy and feature layout text
├── products.html        # Main inventory browsing catalog
├── products.txt         # Comprehensive product catalog copy
├── desktop.ini          # System configuration file
│
├── [Collection Pages]
│   ├── gold-chain.html     # Curated Gold Chain collection showcase
│   ├── gold-chain.txt      # Inventory notes for gold items
│   ├── pearl-necklace.html # Curated Pearl Necklace collection showcase
│   ├── pearl-necklace.txt  # Inventory notes for pearl items
│   ├── product1.html       # Individual product detail view (Style 1)
│   ├── product2.html       # Individual product detail view (Style 2)
│   ├── product3.html       # Individual product detail view (Style 3)
│   ├── product4.html       # Individual product detail view (Style 4)
│
└── [Asset Media]
    ├── abo.jpeg            # About Us promotional/brand header graphic
    ├── bracelet.jpeg       # Product imagery: Core Bracelet Collection
    ├── bracelet2.jpeg      # Product imagery: Alternative Bracelet Variant
    ├── bracelet3.jpeg      # Product imagery: Premium Bracelet Line
    ├── charmbracelet.jpeg  # Product imagery: Personalized Charm Bracelet
    ├── earrings.jpeg       # Product imagery: Core Earring Collection
    ├── earrings2.jpeg      # Product imagery: Alternative Earring Variant
🚀 Getting Started
Prerequisites
You only need a modern web browser (e.g., Chrome, Safari, Firefox, Edge) to run this project. No background compilation, server stacks, or external databases are required.

Local Installation & Preview
Download or clone this repository to your local machine.

Navigate into the website/ directory.

Double-click home page.html to launch the storefront in your default browser.

🛠️ Features & Content
Dynamic Catalog Components: The products.html file serves as the core directory routing users toward specific items (product1.html through product4.html) and dedicated collection pages.

Separated Data Layers: Each template features a corresponding structural .txt file containing the raw copy, layout blocks, and descriptive text used during implementation.

High-Resolution Mock Media: Custom raw binary image strings (.jpeg) are packed inline to dynamically populate product visual cards for the bracelets, earrings, and branding panels.

🏷️ Customization
To modify the text layouts or insert localized brand details:

Review the desired textual templates contained inside the .txt reference sheets.

Open the corresponding .html file inside any standard plain-text or Markdown code editor.

Locate the text bodies inside the semantic blocks (e.g., <p>, <h1>, <div>) and update the string values safely.